'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'

const ALL_EMOJIS = [
  { emoji: '😀', name: 'Grinning Face', category: 'Faces' },
  { emoji: '😂', name: 'Joy', category: 'Faces' },
  { emoji: '🥺', name: 'Pleading', category: 'Faces' },
  { emoji: '😭', name: 'Crying', category: 'Faces' },
  { emoji: '😍', name: 'Heart Eyes', category: 'Faces' },
  { emoji: '🥰', name: 'Smiling Hearts', category: 'Faces' },
  { emoji: '😎', name: 'Cool', category: 'Faces' },
  { emoji: '🤣', name: 'ROFL', category: 'Faces' },
  { emoji: '😊', name: 'Smiling', category: 'Faces' },
  { emoji: '🫠', name: 'Melting', category: 'Faces' },
  { emoji: '😏', name: 'Smirk', category: 'Faces' },
  { emoji: '🙄', name: 'Eye Roll', category: 'Faces' },
  { emoji: '😤', name: 'Triumph', category: 'Faces' },
  { emoji: '🥹', name: 'Holding Tears', category: 'Faces' },
  { emoji: '😶', name: 'No Mouth', category: 'Faces' },
  { emoji: '❤️', name: 'Red Heart', category: 'Hearts' },
  { emoji: '🧡', name: 'Orange Heart', category: 'Hearts' },
  { emoji: '💛', name: 'Yellow Heart', category: 'Hearts' },
  { emoji: '💚', name: 'Green Heart', category: 'Hearts' },
  { emoji: '💙', name: 'Blue Heart', category: 'Hearts' },
  { emoji: '💜', name: 'Purple Heart', category: 'Hearts' },
  { emoji: '🖤', name: 'Black Heart', category: 'Hearts' },
  { emoji: '🩷', name: 'Pink Heart', category: 'Hearts' },
  { emoji: '🩵', name: 'Light Blue Heart', category: 'Hearts' },
  { emoji: '💕', name: 'Two Hearts', category: 'Hearts' },
  { emoji: '💞', name: 'Revolving Hearts', category: 'Hearts' },
  { emoji: '💓', name: 'Beating Heart', category: 'Hearts' },
  { emoji: '💗', name: 'Growing Heart', category: 'Hearts' },
  { emoji: '💖', name: 'Sparkling Heart', category: 'Hearts' },
  { emoji: '💝', name: 'Heart Ribbon', category: 'Hearts' },
  { emoji: '🌸', name: 'Cherry Blossom', category: 'Nature' },
  { emoji: '🌺', name: 'Hibiscus', category: 'Nature' },
  { emoji: '🌻', name: 'Sunflower', category: 'Nature' },
  { emoji: '🌹', name: 'Rose', category: 'Nature' },
  { emoji: '🦋', name: 'Butterfly', category: 'Nature' },
  { emoji: '🌙', name: 'Moon', category: 'Nature' },
  { emoji: '⭐', name: 'Star', category: 'Nature' },
  { emoji: '🌈', name: 'Rainbow', category: 'Nature' },
  { emoji: '🍀', name: 'Clover', category: 'Nature' },
  { emoji: '🌊', name: 'Wave', category: 'Nature' },
  { emoji: '✨', name: 'Sparkles', category: 'Symbols' },
  { emoji: '💀', name: 'Skull', category: 'Symbols' },
  { emoji: '🔥', name: 'Fire', category: 'Symbols' },
  { emoji: '💯', name: '100', category: 'Symbols' },
  { emoji: '⚡', name: 'Lightning', category: 'Symbols' },
  { emoji: '🎯', name: 'Target', category: 'Symbols' },
  { emoji: '👑', name: 'Crown', category: 'Symbols' },
  { emoji: '💎', name: 'Diamond', category: 'Symbols' },
  { emoji: '🏆', name: 'Trophy', category: 'Symbols' },
  { emoji: '🎉', name: 'Party', category: 'Symbols' },
  { emoji: '🍕', name: 'Pizza', category: 'Food' },
  { emoji: '🍔', name: 'Burger', category: 'Food' },
  { emoji: '🍟', name: 'Fries', category: 'Food' },
  { emoji: '🍣', name: 'Sushi', category: 'Food' },
  { emoji: '🍜', name: 'Noodles', category: 'Food' },
  { emoji: '🧁', name: 'Cupcake', category: 'Food' },
  { emoji: '🍰', name: 'Cake', category: 'Food' },
  { emoji: '🍦', name: 'Ice Cream', category: 'Food' },
  { emoji: '🍩', name: 'Donut', category: 'Food' },
  { emoji: '☕', name: 'Coffee', category: 'Food' },
  { emoji: '🐶', name: 'Dog', category: 'Animals' },
  { emoji: '🐱', name: 'Cat', category: 'Animals' },
  { emoji: '🐼', name: 'Panda', category: 'Animals' },
  { emoji: '🦊', name: 'Fox', category: 'Animals' },
  { emoji: '🐨', name: 'Koala', category: 'Animals' },
  { emoji: '🦁', name: 'Lion', category: 'Animals' },
  { emoji: '🐯', name: 'Tiger', category: 'Animals' },
  { emoji: '🐸', name: 'Frog', category: 'Animals' },
  { emoji: '🦄', name: 'Unicorn', category: 'Animals' },
  { emoji: '🐙', name: 'Octopus', category: 'Animals' },
  { emoji: '✈️', name: 'Airplane', category: 'Travel' },
  { emoji: '🚀', name: 'Rocket', category: 'Travel' },
  { emoji: '🏖️', name: 'Beach', category: 'Travel' },
  { emoji: '🗼', name: 'Eiffel Tower', category: 'Travel' },
  { emoji: '🗽', name: 'Statue Liberty', category: 'Travel' },
  { emoji: '🌍', name: 'Earth', category: 'Travel' },
  { emoji: '🏔️', name: 'Mountain', category: 'Travel' },
  { emoji: '🏝️', name: 'Island', category: 'Travel' },
  { emoji: '🎡', name: 'Ferris Wheel', category: 'Travel' },
  { emoji: '🗺️', name: 'Map', category: 'Travel' },
  { emoji: '📱', name: 'Phone', category: 'Objects' },
  { emoji: '💻', name: 'Laptop', category: 'Objects' },
  { emoji: '🎮', name: 'Game Controller', category: 'Objects' },
  { emoji: '📷', name: 'Camera', category: 'Objects' },
  { emoji: '🎧', name: 'Headphones', category: 'Objects' },
  { emoji: '📚', name: 'Books', category: 'Objects' },
  { emoji: '💰', name: 'Money Bag', category: 'Objects' },
  { emoji: '🔑', name: 'Key', category: 'Objects' },
  { emoji: '⚽', name: 'Soccer', category: 'Objects' },
  { emoji: '🎸', name: 'Guitar', category: 'Objects' },
]

const CATEGORIES = ['All', 'Faces', 'Hearts', 'Nature', 'Symbols', 'Food', 'Animals', 'Travel', 'Objects']

export default function CopyPage() {
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [copied, setCopied] = useState(null)
  const [recentlyCopied, setRecentlyCopied] = useState([])
  const [copyCounts, setCopyCounts] = useState({})

  const filtered = ALL_EMOJIS.filter(e => {
    const matchCat = activeCategory === 'All' || e.category === activeCategory
    const matchSearch = e.name.toLowerCase().includes(search.toLowerCase()) || e.emoji.includes(search)
    return matchCat && matchSearch
  })

  const copyEmoji = async (emoji, name) => {
    await navigator.clipboard.writeText(emoji)
    setCopied(emoji)
    setRecentlyCopied(prev => {
      const filtered = prev.filter(e => e.emoji !== emoji)
      return [{ emoji, name }, ...filtered].slice(0, 8)
    })
    setCopyCounts(prev => ({ ...prev, [emoji]: (prev[emoji] || 0) + 1 }))
    setTimeout(() => setCopied(null), 1500)
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg, #0a0a0f)', color: 'var(--text, #f0f0f5)', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        :root { --bg:#0a0a0f; --bg2:#111118; --bg3:#1a1a24; --text:#f0f0f5; --muted:#8a8a9a; --border:rgba(255,255,255,0.07); --accent:#7c6fff; --pink:#ff6fb0; }
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap');
        .emoji-btn { background: var(--bg2); border: 1px solid var(--border); border-radius: 12px; padding: 10px 6px; text-align: center; cursor: pointer; transition: all 0.15s; }
        .emoji-btn:hover { border-color: rgba(124,111,255,0.3); background: rgba(124,111,255,0.08); transform: translateY(-2px); }
        .emoji-btn.copied-state { border-color: rgba(124,111,255,0.5); background: rgba(124,111,255,0.15); }
        .cat-btn { padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 500; cursor: pointer; border: 1px solid var(--border); color: var(--muted); background: transparent; transition: all 0.15s; white-space: nowrap; }
        .cat-btn.active { background: rgba(124,111,255,0.15); border-color: rgba(124,111,255,0.4); color: #a09aff; }
        .search-bar { background: var(--bg2); border: 1px solid rgba(255,255,255,0.12); color: var(--text); outline: none; border-radius: 12px; padding: 10px 14px 10px 40px; font-size: 14px; width: 100%; transition: border-color 0.2s; }
        .search-bar:focus { border-color: var(--accent); }
        .toast { position: fixed; bottom: 70px; left: 50%; transform: translateX(-50%); background: #7c6fff; color: white; padding: 10px 20px; border-radius: 20px; font-size: 13px; font-weight: 500; z-index: 100; animation: slideUp 0.3s ease; }
        @keyframes slideUp { from { opacity:0; transform: translateX(-50%) translateY(10px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }
        .nav-bar { position: fixed; bottom: 0; left: 0; right: 0; background: rgba(17,17,24,0.97); border-top: 1px solid var(--border); display: flex; height: 56px; z-index: 50; }
        .nav-item { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; cursor: pointer; font-size: 8px; color: var(--muted); text-decoration: none; }
        .nav-item.active { color: var(--accent); }
        .grad-text { background: linear-gradient(135deg,#7c6fff,#ff6fb0); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
      `}</style>

      {/* Navbar */}
      <nav style={{ background: 'rgba(10,10,15,0.95)', borderBottom: '1px solid var(--border)', padding: '0 16px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 40 }}>
        <Link href="/" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, textDecoration: 'none' }}>
          <span className="grad-text">EmojiMeaning.co</span>
        </Link>
        <span style={{ fontSize: 12, color: 'var(--muted)' }}>📋 Copy Emojis</span>
      </nav>

      <div style={{ padding: '16px', maxWidth: '800px', margin: '0 auto', paddingBottom: '80px' }}>
        {/* Title */}
        <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, marginBottom: 4 }}>
          <span className="grad-text">Copy Any Emoji</span>
        </h1>
        <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 16 }}>One tap to copy — instant!</p>

        {/* Search */}
        <div style={{ position: 'relative', marginBottom: 12 }}>
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 16 }}>🔍</span>
          <input className="search-bar" placeholder="Search emoji..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {/* Categories */}
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', marginBottom: 16, paddingBottom: 4, scrollbarWidth: 'none' }}>
          {CATEGORIES.map(cat => (
            <button key={cat} className={`cat-btn ${activeCategory === cat ? 'active' : ''}`} onClick={() => setActiveCategory(cat)}>{cat}</button>
          ))}
        </div>

        {/* Recently Copied */}
        {recentlyCopied.length > 0 && (
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 500, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>⏱ Recently Copied</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {recentlyCopied.map((e, i) => (
                <button key={i} className="emoji-btn" onClick={() => copyEmoji(e.emoji, e.name)} style={{ padding: '8px 12px', fontSize: 22 }}>
                  {e.emoji}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Emoji Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(70px, 1fr))', gap: 8 }}>
          {filtered.map((e, i) => (
            <button key={i} className={`emoji-btn ${copied === e.emoji ? 'copied-state' : ''}`} onClick={() => copyEmoji(e.emoji, e.name)}>
              <div style={{ fontSize: 28, marginBottom: 4 }}>{e.emoji}</div>
              <div style={{ fontSize: 9, color: 'var(--muted)', lineHeight: 1.2 }}>{e.name}</div>
              {copyCounts[e.emoji] > 0 && (
                <div style={{ fontSize: 8, color: '#7c6fff', marginTop: 2 }}>×{copyCounts[e.emoji]}</div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Toast */}
      {copied && <div className="toast">✅ {copied} Copied!</div>}

      {/* Bottom Nav */}
      <nav className="nav-bar">
        <Link href="/" className="nav-item"><span style={{ fontSize: 20 }}>🏠</span>Home</Link>
        <Link href="/copy" className="nav-item active"><span style={{ fontSize: 20 }}>📋</span>Copy</Link>
        <Link href="/combine" className="nav-item"><span style={{ fontSize: 20 }}>✨</span>Combine</Link>
      </nav>
    </div>
  )
}
