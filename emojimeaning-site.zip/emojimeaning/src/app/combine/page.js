'use client'
import { useState } from 'react'
import Link from 'next/link'

const PICK_EMOJIS = [
  '😀','😂','🥺','😭','😍','🥰','😎','🤣','😊','🫠','😏','🙄',
  '❤️','🧡','💛','💚','💙','💜','🖤','🩷','💕','💖',
  '🌸','🌺','🌻','🌹','🦋','🌙','⭐','🌈','🍀','🌊',
  '✨','💀','🔥','💯','⚡','🎯','👑','💎','🏆','🎉',
  '🍕','🍔','🍣','🧁','🍦','☕','🐶','🐱','🐼','🦊',
  '🦁','🐸','🦄','🚀','🌍','📱','💻','🎮','🎧','💰',
]

const COMBINATIONS = {
  '😂❤️': '😂', '💀🔥': '💀', '🦋✨': '🦋', '🌙⭐': '🌟',
  '😭🥺': '😢', '❤️🔥': '❤️‍🔥', '🐸🔥': '🐸', '🌸🌙': '🌸',
  '👑💎': '👑', '🎯🔥': '🎯', '🦄✨': '🦄', '🌈⭐': '🌈',
}

export default function CombinePage() {
  const [emoji1, setEmoji1] = useState('🐸')
  const [emoji2, setEmoji2] = useState('🔥')
  const [result, setResult] = useState(null)
  const [selecting, setSelecting] = useState(1)
  const [recentCombos, setRecentCombos] = useState([])
  const [sparkle, setSparkle] = useState(false)
  const [copied, setCopied] = useState(false)

  const combine = () => {
    const key1 = emoji1 + emoji2
    const key2 = emoji2 + emoji1
    const combined = COMBINATIONS[key1] || COMBINATIONS[key2] || emoji1 + emoji2
    setResult(combined)
    setSparkle(true)
    setTimeout(() => setSparkle(false), 1000)
    setRecentCombos(prev => [{ e1: emoji1, e2: emoji2, result: combined }, ...prev].slice(0, 6))
  }

  const copyResult = async () => {
    if (!result) return
    await navigator.clipboard.writeText(result)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const share = () => {
    if (navigator.share && result) {
      navigator.share({ text: `I combined ${emoji1} + ${emoji2} = ${result} on EmojiMeaning.co!` })
    }
  }

  const pickEmoji = (em) => {
    if (selecting === 1) { setEmoji1(em); setSelecting(2) }
    else { setEmoji2(em); setSelecting(1) }
    setResult(null)
  }

  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0f', color: '#f0f0f5', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        :root { --bg:#0a0a0f; --bg2:#111118; --bg3:#1a1a24; --text:#f0f0f5; --muted:#8a8a9a; --border:rgba(255,255,255,0.07); --accent:#7c6fff; }
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap');
        .grad-text { background: linear-gradient(135deg,#7c6fff,#ff6fb0); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .combo-box { width: 80px; height: 80px; background: #111118; border: 2px dashed rgba(255,255,255,0.15); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 40px; cursor: pointer; transition: all 0.2s; }
        .combo-box.selected { border-color: rgba(124,111,255,0.6); background: rgba(124,111,255,0.1); }
        .combo-box:hover { border-color: rgba(124,111,255,0.4); }
        .combine-btn { width: 100%; background: linear-gradient(135deg,#7c6fff,#ff6fb0); border: none; border-radius: 14px; color: white; padding: 14px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all 0.2s; margin-top: 16px; }
        .combine-btn:hover { transform: translateY(-1px); opacity: 0.9; }
        .pick-btn { font-size: 24px; padding: 8px; border-radius: 10px; background: #111118; border: 1px solid rgba(255,255,255,0.07); cursor: pointer; transition: all 0.15s; text-align: center; }
        .pick-btn:hover { background: rgba(124,111,255,0.1); border-color: rgba(124,111,255,0.3); transform: scale(1.1); }
        .action-btn { flex: 1; padding: 10px; border-radius: 12px; font-size: 13px; font-weight: 500; cursor: pointer; border: 1px solid rgba(255,255,255,0.1); background: rgba(255,255,255,0.04); color: #f0f0f5; transition: all 0.15s; }
        .action-btn:hover { background: rgba(124,111,255,0.1); border-color: rgba(124,111,255,0.3); }
        .sparkle { animation: sparkleAnim 0.5s ease; }
        @keyframes sparkleAnim { 0% { transform: scale(1); } 50% { transform: scale(1.3) rotate(10deg); } 100% { transform: scale(1); } }
        .nav-bar { position: fixed; bottom: 0; left: 0; right: 0; background: rgba(17,17,24,0.97); border-top: 1px solid rgba(255,255,255,0.07); display: flex; height: 56px; z-index: 50; }
        .nav-item { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; cursor: pointer; font-size: 8px; color: #8a8a9a; text-decoration: none; }
        .nav-item.active { color: #7c6fff; }
      `}</style>

      <nav style={{ background: 'rgba(10,10,15,0.95)', borderBottom: '1px solid rgba(255,255,255,0.07)', padding: '0 16px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 40 }}>
        <Link href="/" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, textDecoration: 'none' }}>
          <span className="grad-text">EmojiMeaning.co</span>
        </Link>
        <span style={{ fontSize: 12, color: '#8a8a9a' }}>✨ Combiner</span>
      </nav>

      <div style={{ padding: '16px', maxWidth: '500px', margin: '0 auto', paddingBottom: '80px' }}>
        <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, marginBottom: 4 }}>
          <span className="grad-text">Emoji Combiner</span>
        </h1>
        <p style={{ color: '#8a8a9a', fontSize: 13, marginBottom: 20 }}>Mix two emojis — see what you get!</p>

        {/* Selector boxes */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 10, color: '#8a8a9a', textAlign: 'center', marginBottom: 6 }}>Emoji 1</div>
            <div className={`combo-box ${selecting === 1 ? 'selected' : ''}`} onClick={() => setSelecting(1)}>{emoji1}</div>
          </div>
          <div style={{ fontSize: 24, color: '#55556a', fontWeight: 300 }}>+</div>
          <div>
            <div style={{ fontSize: 10, color: '#8a8a9a', textAlign: 'center', marginBottom: 6 }}>Emoji 2</div>
            <div className={`combo-box ${selecting === 2 ? 'selected' : ''}`} onClick={() => setSelecting(2)}>{emoji2}</div>
          </div>
        </div>

        <div style={{ fontSize: 11, color: '#7c6fff', textAlign: 'center', marginBottom: 12 }}>
          Tapping → Emoji {selecting} select ho raha hai
        </div>

        <button className="combine-btn" onClick={combine}>✨ Combine!</button>

        {/* Result */}
        {result && (
          <div style={{ marginTop: 20, background: 'rgba(124,111,255,0.08)', border: '1px solid rgba(124,111,255,0.25)', borderRadius: 20, padding: 20, textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: '#a09aff', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Result</div>
            <div className={sparkle ? 'sparkle' : ''} style={{ fontSize: 60, marginBottom: 8 }}>{result}</div>
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              <button className="action-btn" onClick={copyResult}>{copied ? '✅ Copied!' : '📋 Copy'}</button>
              <button className="action-btn" onClick={share}>🔗 Share</button>
            </div>
          </div>
        )}

        {/* Emoji picker */}
        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 12, color: '#8a8a9a', marginBottom: 10, fontWeight: 500 }}>Pick Emoji {selecting}:</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 6 }}>
            {PICK_EMOJIS.map((em, i) => (
              <button key={i} className="pick-btn" onClick={() => pickEmoji(em)}>{em}</button>
            ))}
          </div>
        </div>

        {/* Recent combos */}
        {recentCombos.length > 0 && (
          <div style={{ marginTop: 20 }}>
            <div style={{ fontSize: 12, color: '#8a8a9a', marginBottom: 10, fontWeight: 500 }}>⏱ Recent Combos</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {recentCombos.map((c, i) => (
                <div key={i} style={{ background: '#111118', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '6px 12px', fontSize: 18 }}>
                  {c.e1}+{c.e2}={c.result}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <nav className="nav-bar">
        <Link href="/" className="nav-item"><span style={{ fontSize: 20 }}>🏠</span>Home</Link>
        <Link href="/copy" className="nav-item"><span style={{ fontSize: 20 }}>📋</span>Copy</Link>
        <Link href="/combine" className="nav-item active"><span style={{ fontSize: 20 }}>✨</span>Combine</Link>
      </nav>
    </div>
  )
}
