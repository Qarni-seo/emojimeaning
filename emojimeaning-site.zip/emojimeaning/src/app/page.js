'use client'
import Link from 'next/link'
import { useState } from 'react'
import { emojis, categories } from '@/data/emojis'

const trendingEmojis = [
  { emoji: "💀", label: "Skull", slug: "skull-emoji-meaning" },
  { emoji: "🦋", label: "Butterfly", slug: "butterfly-emoji-meaning" },
  { emoji: "🫠", label: "Melting", slug: "melting-face-emoji-meaning" },
  { emoji: "❤️", label: "Heart", slug: "heart-emoji-meaning" },
  { emoji: "😭", label: "Crying", slug: "crying-emoji-meaning" },
  { emoji: "🔥", label: "Fire", slug: "fire-emoji-meaning" },
  { emoji: "✨", label: "Sparkles", slug: "sparkles-emoji-meaning" },
  { emoji: "🥺", label: "Pleading", slug: "pleading-face-emoji-meaning" },
]

export default function HomePage() {
  const [search, setSearch] = useState('')
  const [copied, setCopied] = useState(null)

  const filtered = search.length > 1
    ? emojis.filter(e =>
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.emoji.includes(search)
      )
    : emojis

  return (
    <>
      {/* Schema.org structured data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "EmojiMeaning.co",
            "url": "https://emojimeaning.co",
            "description": "The complete emoji meaning dictionary for 2026",
            "potentialAction": {
              "@type": "SearchAction",
              "target": "https://emojimeaning.co/search?q={search_term_string}",
              "query-input": "required name=search_term_string"
            }
          })
        }}
      />

      <div className="min-h-screen grid-bg relative">
        {/* Orbs */}
        <div className="orb orb-purple w-[600px] h-[600px] top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-60" />
        <div className="orb orb-pink w-[400px] h-[400px] top-40 right-0 opacity-40" />

        {/* Navbar */}
        <nav className="navbar sticky top-0 z-50">
          <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
            <Link href="/" className="font-display font-bold text-xl flex items-center gap-2">
              <span className="text-2xl">✨</span>
              <span className="gradient-text">EmojiMeaning</span>
              <span className="text-[var(--text-muted)]">.co</span>
            </Link>
            <div className="hidden sm:flex items-center gap-6 text-sm text-[var(--text-muted)]">
              <Link href="#trending" className="hover:text-[var(--text)] transition-colors">Trending</Link>
              <Link href="#categories" className="hover:text-[var(--text)] transition-colors">Categories</Link>
              <Link href="#all" className="hover:text-[var(--text)] transition-colors">All Emojis</Link>
            </div>
          </div>
        </nav>

        {/* Hero */}
        <section className="relative pt-16 pb-20 px-4 text-center overflow-hidden">
          <div className="max-w-4xl mx-auto">
            <div className="fade-up fade-up-1">
              <span className="tag mb-6 inline-block">Updated for 2026 · Gen Z Meanings Included</span>
            </div>

            <h1 className="font-display font-extrabold text-5xl sm:text-6xl md:text-7xl leading-[1.05] mb-6 fade-up fade-up-2">
              What Does Every<br />
              <span className="gradient-text">Emoji Really Mean?</span>
            </h1>

            <p className="text-[var(--text-muted)] text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed fade-up fade-up-3">
              Official meanings, Gen Z slang, and what emojis mean <em>from a guy or girl</em> — all in one place. No guessing. Just answers.
            </p>

            {/* Search */}
            <div className="fade-up fade-up-4 max-w-lg mx-auto relative">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl">🔍</span>
                <input
                  type="text"
                  placeholder="Search emoji or paste it here..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="search-input w-full pl-12 pr-4 py-4 rounded-2xl text-base"
                />
              </div>
              {search && (
                <div className="absolute top-full left-0 right-0 mt-2 glass rounded-2xl overflow-hidden z-20 shadow-2xl">
                  {filtered.length > 0 ? filtered.slice(0, 5).map(e => (
                    <Link
                      key={e.slug}
                      href={`/${e.slug}`}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors"
                      onClick={() => setSearch('')}
                    >
                      <span className="text-3xl">{e.emoji}</span>
                      <div className="text-left">
                        <div className="text-sm font-medium text-[var(--text)]">{e.name}</div>
                        <div className="text-xs text-[var(--text-muted)] truncate">{e.genZMeaning.slice(0, 60)}...</div>
                      </div>
                    </Link>
                  )) : (
                    <div className="px-4 py-6 text-center text-[var(--text-muted)] text-sm">No emoji found</div>
                  )}
                </div>
              )}
            </div>

            {/* Quick stats */}
            <div className="flex flex-wrap justify-center gap-8 mt-12 fade-up fade-up-4">
              {[
                { num: "3,000+", label: "Emojis Covered" },
                { num: "2026", label: "Updated Meanings" },
                { num: "Gen Z", label: "Slang Included" },
              ].map((s, i) => (
                <div key={i} className="text-center">
                  <div className="font-display font-bold text-2xl gradient-text">{s.num}</div>
                  <div className="text-xs text-[var(--text-muted)] mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Trending Now */}
        <section id="trending" className="py-16 px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-3 mb-10">
              <span className="text-2xl">🔥</span>
              <h2 className="font-display font-bold text-2xl sm:text-3xl">Trending Emojis</h2>
              <span className="tag text-xs ml-2">Most Searched</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {trendingEmojis.map((item, i) => (
                <Link
                  key={item.slug}
                  href={`/${item.slug}`}
                  className="glass rounded-2xl p-5 text-center group cursor-pointer transition-all duration-300 hover:border-[rgba(124,111,255,0.3)] hover:-translate-y-1"
                >
                  <div className="text-5xl mb-3 group-hover:scale-110 transition-transform duration-300 inline-block">
                    {item.emoji}
                  </div>
                  <div className="font-display font-semibold text-sm text-[var(--text)]">{item.label}</div>
                  <div className="text-xs text-[var(--text-dim)] mt-1">Tap to learn →</div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Categories */}
        <section id="categories" className="py-16 px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="font-display font-bold text-2xl sm:text-3xl mb-10 flex items-center gap-3">
              <span>📂</span> Browse by Category
            </h2>
            <div className="flex flex-wrap gap-3">
              {categories.map(cat => (
                <button
                  key={cat.slug}
                  className="glass px-5 py-3 rounded-full flex items-center gap-2 text-sm font-medium hover:border-[rgba(124,111,255,0.3)] hover:text-[var(--accent)] transition-all"
                >
                  <span className="text-lg">{cat.emoji}</span>
                  {cat.name}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* All Emojis Grid */}
        <section id="all" className="py-16 px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="font-display font-bold text-2xl sm:text-3xl mb-10 flex items-center gap-3">
              <span>✨</span> All Emoji Meanings
            </h2>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {emojis.map((item) => (
                <Link
                  key={item.slug}
                  href={`/${item.slug}`}
                  className="glass rounded-2xl p-5 group hover:border-[rgba(124,111,255,0.25)] transition-all duration-200 hover:-translate-y-1"
                >
                  <div className="flex items-start gap-4">
                    <div className="text-5xl group-hover:scale-110 transition-transform duration-200 flex-shrink-0">
                      {item.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-display font-semibold text-base text-[var(--text)] mb-1">{item.name}</div>
                      <div className="text-xs text-[var(--text-muted)] line-clamp-2 leading-relaxed">
                        {item.genZMeaning}
                      </div>
                      <div className="flex items-center gap-2 mt-3">
                        <span className="text-xs text-[var(--accent)] font-medium">See meaning →</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section — AEO */}
        <section className="py-16 px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-display font-bold text-2xl sm:text-3xl mb-10 text-center">
              Frequently Asked Questions
            </h2>
            <script
              type="application/ld+json"
              dangerouslySetInnerHTML={{
                __html: JSON.stringify({
                  "@context": "https://schema.org",
                  "@type": "FAQPage",
                  "mainEntity": [
                    {
                      "@type": "Question",
                      "name": "What does 💀 skull emoji mean?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "The skull emoji 💀 means 'I'm dead' — as in something is SO funny you died laughing. Gen Z uses it as a replacement for 😂."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "What does 🦋 butterfly emoji mean from a guy?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "If a guy sends 🦋 he's telling you that you give him butterflies. It's romantic and means he genuinely likes you."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "What does 😭 mean in texting?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "In 2026, 😭 almost never means sadness in texting. For Gen Z it means something is SO funny or cute that you're crying laughing."
                      }
                    }
                  ]
                })
              }}
            />
            <div className="space-y-4">
              {[
                {
                  q: "What does 💀 skull emoji mean?",
                  a: "In 2026, 💀 means 'I'm dead' — something is SO funny you literally died laughing. Gen Z uses it as a full replacement for 😂."
                },
                {
                  q: "What does 🦋 mean from a guy?",
                  a: "He's telling you that you give him butterflies. It's romantic, vulnerable, and means he genuinely likes you — guys rarely use this casually."
                },
                {
                  q: "What does 😭 mean in texting?",
                  a: "Almost never sadness. In 2026, 😭 means something is SO funny or cute that you're crying. The #1 emoji on social media with 814 million mentions in 2025."
                },
                {
                  q: "Why do emojis mean different things to different generations?",
                  a: "Internet culture evolves fast. Gen Z repurposes emojis through memes and social media — 💀 used to mean death, now it means laughter. This site tracks both."
                },
              ].map((faq, i) => (
                <details
                  key={i}
                  className="glass rounded-2xl overflow-hidden group"
                >
                  <summary className="px-6 py-5 cursor-pointer font-medium text-[var(--text)] list-none flex items-center justify-between hover:text-[var(--accent)] transition-colors">
                    {faq.q}
                    <span className="text-[var(--text-dim)] group-open:rotate-180 transition-transform text-sm ml-4 flex-shrink-0">▼</span>
                  </summary>
                  <div className="px-6 pb-5 text-[var(--text-muted)] text-sm leading-relaxed border-t border-[var(--border)] pt-4">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-[var(--border)] py-12 px-4 mt-8">
          <div className="max-w-6xl mx-auto text-center">
            <div className="font-display font-bold text-xl mb-3">
              <span className="gradient-text">EmojiMeaning.co</span>
            </div>
            <p className="text-[var(--text-dim)] text-sm mb-6">
              The internet's most complete emoji meaning dictionary. Updated for 2026.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-[var(--text-muted)]">
              <Link href="/" className="hover:text-[var(--text)] transition-colors">Home</Link>
              <Link href="/about" className="hover:text-[var(--text)] transition-colors">About</Link>
              <Link href="/privacy" className="hover:text-[var(--text)] transition-colors">Privacy</Link>
            </div>
            <p className="text-[var(--text-dim)] text-xs mt-8">© 2026 EmojiMeaning.co · All meanings updated regularly</p>
          </div>
        </footer>
      </div>
    </>
  )
}
