import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  metadataBase: new URL('https://emojimeaning.co'),
  title: {
    default: 'EmojiMeaning.co — What Does Every Emoji Mean?',
    template: '%s | EmojiMeaning.co'
  },
  description: 'Discover what every emoji really means in 2026 — Gen Z meanings, what emojis mean from a guy or girl, and texting context explained.',
  keywords: ['emoji meaning', 'what does emoji mean', 'emoji meanings 2026', 'emoji meaning from guy', 'emoji meaning from girl'],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://emojimeaning.co',
    siteName: 'EmojiMeaning.co',
    title: 'EmojiMeaning.co — What Does Every Emoji Really Mean?',
    description: 'The complete emoji meaning dictionary for 2026. Gen Z slang, texting context, and relationship meanings explained.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'EmojiMeaning.co — What Does Every Emoji Mean?',
    description: 'The complete emoji meaning dictionary for 2026.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet" />
      </head>
      <body className={inter.className} suppressHydrationWarning>
        {children}
      </body>
    </html>
  )
}
