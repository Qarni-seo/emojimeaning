'use client'
import Link from 'next/link'
import { useState } from 'react'
import { getEmojiBySlug, emojis } from '@/data/emojis'
import { notFound } from 'next/navigation'

function CopyButton({ emoji }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(emoji)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button
      onClick={copy}
      className="copy-btn flex items-center gap-2 px-6 py-3 rounded-2xl font-medium text-sm transition-all"
      style={{
        background: copied ? 'rgba(124,111,255,0.2)' : 'rgba(255,255,255,0.05)',
        border: `1px solid ${copied ? 'rgba(124,111,255,0.4)' : 'rgba(255,255,255,0.1)'}`,
        color: copied ? '#a09aff' : '#f0f0f5'
      }}
    >
      {copied ? '✅ Copied!' : `📋 Copy ${emoji}`}
    </button>
  )
}

function MeaningCard({ icon, title, color, children }) {
  const colors = {
    purple: { bg: 'rgba(124,111,255,0.08)', border: 'rgba(124,111,255,0.2)', icon: '#a09aff' },
    pink: { bg: 'rgba(255,111,176,0.08)', border: 'rgba(255,111,176,0.2)', icon: '#ff6fb0' },
    orange: { bg: 'rgba(255,184,108,0.08)', border: 'rgba(255,184,108,0.2)', icon: '#ffb86c' },
    blue: { bg: 'rgba(108,184,255,0.08)', border: 'rgba(108,184,255,0.2)', icon: '#6cb8ff' },
  }
  const c = colors[color] || colors.purple
  return (
    <div className="meaning-card" style={{ background: c.bg, borderColor: c.border }}>
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">{icon}</span>
        <h3 className="font-display font-bold text-base" style={{ color: c.icon }}>{title}</h3>
      </div>
      <p className="text-[var(--text-muted)] text-sm leading-relaxed">{children}</p>
    </div>
  )
}

export default function EmojiPage({ params }) {
  const data = getEmojiBySlug(params.slug)
  if (!data) notFound()

  const related = emojis.filter(e => e.slug !== data.slug).slice(0, 6)

  const schemaData = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": data.title,
    "description": data.metaDescription,
    "url": `https://emojimeaning.co/${data.slug}`,
    "author": { "@type": "Organization", "name": "EmojiMeaning.co" },
    "publisher": {
      "@type": "Organization",
      "name": "EmojiMeaning.co",
      "url": "https://emojimeaning.co"
    },
    "dateModified": "2026-05-01",
    "mainEntityOfPage": { "@type": "WebPage", "@id": `https://emojimeaning.co/${data.slug}` }
  }

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": `What does ${data.emoji} mean?`,
        "acceptedAnswer": { "@type": "Answer", "text": data.officialMeaning }
      },
      {
        "@type": "Question",
        "name": `What does ${data.emoji} mean in Gen Z slang?`,
        "acceptedAnswer": { "@type": "Answer", "text": data.genZMeaning }
      },
      {
        "@type": "Question",
        "name": `What does ${data.emoji} mean from a guy?`,
        "acceptedAnswer": { "@type": "Answer", "text": data.fromGuy }
      },
      {
        "@type": "Question",
        "name": `What does ${data.emoji} mean from a girl?`,
        "acceptedAnswer": { "@type": "Answer", "text": data.fromGirl }
      }
    ]
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />

      <div className="min-h-screen grid-bg relative">
        {/* Orbs */}
        <div className="orb orb-purple w-[500px] h-[500px] top-0 left-1/2 -translate-x-1/2 -translate-y-1/3 opacity-50" />

        {/* Navbar */}
        <nav className="navbar sticky top-0 z-50">
          <div className="max-w-4xl mx-auto px-4 h-16 flex items-center gap-4">
            <Link href="/" className="text-[var(--text-muted)] hover:text-[var(--text)] transition-colors text-sm flex items-center gap-1">
              ← Back
            </Link>
            <span className="text-[var(--border-bright)]">|</span>
            <Link href="/" className="font-display font-bold text-lg">
              <span className="gradient-text">EmojiMeaning</span>
              <span className="text-[var(--text-muted)]">.co</span>
            </Link>
          </div>
        </nav>

        {/* Breadcrumb — SEO */}
        <div className="max-w-4xl mx-auto px-4 pt-4">
          <nav aria-label="breadcrumb" className="text-xs text-[var(--text-dim)]">
            <ol className="flex items-center gap-2">
              <li><Link href="/" className="hover:text-[var(--text-muted)] transition-colors">Home</Link></li>
              <li>›</li>
              <li className="text-[var(--text-muted)]">{data.name}</li>
            </ol>
          </nav>
        </div>

        {/* Hero */}
        <section className="pt-10 pb-12 px-4 text-center">
          <div className="max-w-4xl mx-auto">
            {/* Emoji big display */}
            <div className="emoji-hero mb-6">{data.emoji}</div>

            <h1 className="font-display font-extrabold text-4xl sm:text-5xl md:text-6xl mb-4 fade-up fade-up-1">
              {data.name}
              <br />
              <span className="gradient-text text-3xl sm:text-4xl font-bold">Meaning</span>
            </h1>

            <p className="text-[var(--text-muted)] text-base sm:text-lg max-w-2xl mx-auto mb-8 leading-relaxed fade-up fade-up-2">
              {data.officialMeaning}
            </p>

            {/* Action buttons */}
            <div className="flex flex-wrap justify-center gap-3 fade-up fade-up-3">
              <CopyButton emoji={data.emoji} />
              <div className="flex items-center gap-2 px-5 py-3 rounded-2xl text-sm text-[var(--text-muted)]" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                🔥 {data.searchVolume} monthly searches
              </div>
            </div>
          </div>
        </section>

        {/* Meaning Cards */}
        <section className="py-8 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display font-bold text-xl sm:text-2xl mb-6 flex items-center gap-2">
              <span>📖</span> All Meanings Explained
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <MeaningCard icon="🌐" title="Official Meaning" color="purple">
                {data.officialMeaning}
              </MeaningCard>
              <MeaningCard icon="💀" title="Gen Z Meaning (2026)" color="pink">
                {data.genZMeaning}
              </MeaningCard>
              <MeaningCard icon="👦" title={`${data.emoji} from a Guy`} color="blue">
                {data.fromGuy}
              </MeaningCard>
              <MeaningCard icon="👧" title={`${data.emoji} from a Girl`} color="orange">
                {data.fromGirl}
              </MeaningCard>
            </div>
          </div>
        </section>

        {/* Platform Meanings */}
        <section className="py-8 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display font-bold text-xl sm:text-2xl mb-6 flex items-center gap-2">
              <span>📱</span> Platform Meanings
            </h2>
            <div className="grid gap-3 sm:grid-cols-3">
              {Object.entries(data.platforms).map(([platform, meaning]) => (
                <div key={platform} className="platform-badge">
                  <div className="text-xs font-semibold text-[var(--accent)] mb-2 uppercase tracking-wide">
                    {platform === 'whatsapp' ? '💬 WhatsApp' : platform === 'instagram' ? '📸 Instagram' : '🍎 iMessage'}
                  </div>
                  <div className="text-sm text-[var(--text-muted)] leading-relaxed">{meaning}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Quick Answer Box — AEO Featured Snippet Bait */}
        <section className="py-8 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="rounded-2xl p-6 sm:p-8" style={{ background: 'linear-gradient(135deg, rgba(124,111,255,0.1), rgba(255,111,176,0.1))', border: '1px solid rgba(124,111,255,0.2)' }}>
              <div className="text-xs font-bold uppercase tracking-widest text-[var(--accent)] mb-3">Quick Answer</div>
              <h2 className="font-display font-bold text-lg sm:text-xl mb-3">
                What does {data.emoji} {data.name} mean?
              </h2>
              <p className="text-[var(--text-muted)] text-sm leading-relaxed">
                <strong className="text-[var(--text)]">Official:</strong> {data.officialMeaning}<br /><br />
                <strong className="text-[var(--text)]">In 2026:</strong> {data.genZMeaning}
              </p>
            </div>
          </div>
        </section>

        {/* Related Emojis */}
        <section className="py-8 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display font-bold text-xl sm:text-2xl mb-6 flex items-center gap-2">
              <span>✨</span> Related Emojis
            </h2>
            <div className="flex flex-wrap gap-3">
              {related.map(e => (
                <Link key={e.slug} href={`/${e.slug}`} className="emoji-chip">
                  <span>{e.emoji}</span>
                  <span className="text-xs text-[var(--text-muted)] font-medium hidden sm:inline">{e.name.split(' ')[0]}</span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-[var(--border)] py-10 px-4 mt-8 text-center">
          <Link href="/" className="font-display font-bold text-lg">
            <span className="gradient-text">EmojiMeaning.co</span>
          </Link>
          <p className="text-[var(--text-dim)] text-xs mt-3">
            The complete emoji meaning dictionary · Updated 2026
          </p>
        </footer>
      </div>
    </>
  )
}
