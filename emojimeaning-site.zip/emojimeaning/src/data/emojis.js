export const emojis = [
  {
    slug: "skull-emoji-meaning",
    emoji: "💀",
    name: "Skull Emoji",
    title: "💀 Skull Emoji Meaning",
    officialMeaning: "A classic skull and crossbones — originally representing death, danger, or poison.",
    genZMeaning: "In 2026, 💀 means 'I'm dead' — as in something is SO funny you literally died laughing. It replaced 😂 for Gen Z completely.",
    fromGuy: "If a guy sends you 💀 he's dying of laughter at something you said. It's a huge compliment — you're genuinely funny to him.",
    fromGirl: "Same energy — she found something hilarious. If she adds it after a flirty text, she's being playful and comfortable with you.",
    platforms: {
      whatsapp: "Used as extreme laughter or dark humor",
      instagram: "Comments use it to say 'this killed me'",
      imessage: "Replaces LOL entirely for younger users"
    },
    relatedEmojis: ["😂", "💀", "🤣", "😭", "🫠"],
    searchVolume: "500K/mo",
    category: "faces",
    metaDescription: "💀 Skull emoji meaning explained — what it means in texting, from a guy, from a girl, and in Gen Z slang. Updated 2026."
  },
  {
    slug: "butterfly-emoji-meaning",
    emoji: "🦋",
    name: "Butterfly Emoji",
    title: "🦋 Butterfly Emoji Meaning",
    officialMeaning: "A colorful butterfly — representing transformation, beauty, and nature.",
    genZMeaning: "🦋 means butterflies in your stomach — that nervous-excited feeling when you like someone. Also used for glow-ups and personal growth.",
    fromGuy: "If a guy sends 🦋 he's telling you that you give him butterflies. It's romantic and vulnerable — he really likes you.",
    fromGirl: "She's either expressing that she likes you, celebrating a personal transformation, or just thinks something is beautiful.",
    platforms: {
      whatsapp: "Romance and personal growth contexts",
      instagram: "Aesthetic posts, glow-up content",
      imessage: "Flirting and expressing excitement"
    },
    relatedEmojis: ["🌸", "✨", "🌺", "💕", "🥰"],
    searchVolume: "200K/mo",
    category: "nature",
    metaDescription: "🦋 Butterfly emoji meaning — what it means from a guy, from a girl, in texting and relationships. Full 2026 guide."
  },
  {
    slug: "melting-face-emoji-meaning",
    emoji: "🫠",
    name: "Melting Face Emoji",
    title: "🫠 Melting Face Emoji Meaning",
    officialMeaning: "A yellow smiley face that appears to be melting downward — added in Emoji 14.0 in 2021.",
    genZMeaning: "Used when something is so awkward, overwhelming, or cringe that you're literally melting with discomfort. Also used sarcastically for 'I'm fine' when you're clearly not.",
    fromGuy: "He's being sarcastic about a stressful situation, or showing he's awkwardly into you. Context matters a lot here.",
    fromGirl: "Usually means she's overwhelmed, embarrassed, or being sarcastically unbothered about something chaotic.",
    platforms: {
      whatsapp: "Awkward situations and sarcasm",
      instagram: "Relatable stress content",
      imessage: "Gen Z's go-to for 'I'm dying inside but smiling'"
    },
    relatedEmojis: ["😬", "😅", "🙃", "💀", "😶"],
    searchVolume: "120K/mo",
    category: "faces",
    metaDescription: "🫠 Melting face emoji meaning — what it means in texting, from a guy, from a girl. Gen Z meaning explained 2026."
  },
  {
    slug: "heart-emoji-meaning",
    emoji: "❤️",
    name: "Red Heart Emoji",
    title: "❤️ Red Heart Emoji Meaning",
    officialMeaning: "A classic red heart — the universal symbol of love and affection.",
    genZMeaning: "Still the most powerful heart emoji. Sending a plain ❤️ means genuine love or deep appreciation. It hits different than other hearts.",
    fromGuy: "If a guy sends ❤️ he's serious. This isn't a casual emoji for most guys — it means he genuinely cares about you.",
    fromGirl: "Deep affection, love, or strong appreciation. More meaningful than 💕 or 🩷 — she really means it.",
    platforms: {
      whatsapp: "Most used emoji worldwide",
      instagram: "Love reactions on posts",
      imessage: "Serious affection between close people"
    },
    relatedEmojis: ["🩷", "💕", "💗", "🧡", "💛"],
    searchVolume: "300K/mo",
    category: "symbols",
    metaDescription: "❤️ Red heart emoji meaning — what it means from a guy, from a girl, in texting and love. Complete 2026 guide."
  },
  {
    slug: "crying-emoji-meaning",
    emoji: "😭",
    name: "Loudly Crying Emoji",
    title: "😭 Loudly Crying Emoji Meaning",
    officialMeaning: "A yellow face with tears streaming down both cheeks and an open crying mouth.",
    genZMeaning: "The #1 emoji on social media in 2025. For Gen Z it does NOT mean sadness — it means something is SO funny or cute that you're crying. It replaced 😂.",
    fromGuy: "He's either genuinely laughing hard, finding something adorably funny, or being dramatic about something small.",
    fromGirl: "Laughter, finding something too cute, or genuine emotion. In 2026 it's almost always used humorously.",
    platforms: {
      whatsapp: "Both humor and genuine sadness",
      instagram: "814 million mentions in 2025 — #1 emoji",
      imessage: "Replaces LOL for younger generations"
    },
    relatedEmojis: ["💀", "😂", "🤣", "🥺", "😢"],
    searchVolume: "180K/mo",
    category: "faces",
    metaDescription: "😭 Crying emoji meaning — what it really means in 2026, from a guy, from a girl, Gen Z meaning explained."
  },
  {
    slug: "fire-emoji-meaning",
    emoji: "🔥",
    name: "Fire Emoji",
    title: "🔥 Fire Emoji Meaning",
    officialMeaning: "A flame — originally representing fire, heat, or something hot.",
    genZMeaning: "Something is amazing, attractive, or impressive. 'This is fire' = this is incredible. Also used to hype someone up.",
    fromGuy: "He thinks you or something you did is extremely attractive or impressive. It's a strong compliment.",
    fromGirl: "Same — she's hyping you up or saying something is amazing. If sent after your photo, she finds you attractive.",
    platforms: {
      whatsapp: "Compliments and hype",
      instagram: "Briefly overtook 😭 as #1 emoji in Sept 2025",
      imessage: "Attraction and excitement"
    },
    relatedEmojis: ["✨", "💯", "👑", "😍", "🤩"],
    searchVolume: "250K/mo",
    category: "symbols",
    metaDescription: "🔥 Fire emoji meaning — what it means from a guy, from a girl, in texting and Gen Z slang. 2026 guide."
  },
  {
    slug: "sparkles-emoji-meaning",
    emoji: "✨",
    name: "Sparkles Emoji",
    title: "✨ Sparkles Emoji Meaning",
    officialMeaning: "Three golden sparkling stars — representing glitter, magic, or something shiny.",
    genZMeaning: "The most versatile emoji of 2026. Used to add emphasis, express excitement, indicate something is special, or just make text look aesthetic.",
    fromGuy: "He's adding emphasis or being playful. Less commonly used by guys — if he uses it, he has a fun, expressive personality.",
    fromGirl: "She's emphasizing something exciting, being playful, or adding an aesthetic touch. #1 emoji on Instagram.",
    platforms: {
      whatsapp: "Excitement and aesthetics",
      instagram: "#1 emoji on the platform throughout 2025",
      imessage: "Emphasis and celebration"
    },
    relatedEmojis: ["⭐", "🌟", "💫", "🌠", "🎇"],
    searchVolume: "150K/mo",
    category: "symbols",
    metaDescription: "✨ Sparkles emoji meaning — what it means in texting, from a guy, from a girl in 2026. Full guide."
  },
  {
    slug: "pleading-face-emoji-meaning",
    emoji: "🥺",
    name: "Pleading Face Emoji",
    title: "🥺 Pleading Face Emoji Meaning",
    officialMeaning: "A yellow face with big watery puppy eyes, raised eyebrows and a small frown.",
    genZMeaning: "The ultimate 'please' emoji. Used when begging, finding something unbearably cute, or being emotionally vulnerable. Also called the 'puppy eyes emoji'.",
    fromGuy: "He's being soft and vulnerable — either genuinely pleading or finding you adorable. It takes confidence for a guy to send this.",
    fromGirl: "She wants something, finds you cute, or is being emotionally open. One of the most flirty emojis when used in the right context.",
    platforms: {
      whatsapp: "Begging and cute reactions",
      instagram: "Overwhelmed by cuteness",
      imessage: "Vulnerability and asking for things"
    },
    relatedEmojis: ["😢", "🥹", "😔", "💕", "🙏"],
    searchVolume: "90K/mo",
    category: "faces",
    metaDescription: "🥺 Pleading face emoji meaning — puppy eyes emoji explained. What it means from a guy, from a girl in 2026."
  }
];

export const categories = [
  { name: "Faces", slug: "faces", emoji: "😊" },
  { name: "Hearts", slug: "hearts", emoji: "❤️" },
  { name: "Nature", slug: "nature", emoji: "🌿" },
  { name: "Symbols", slug: "symbols", emoji: "✨" },
  { name: "Flirty", slug: "flirty", emoji: "😏" },
  { name: "Gen Z", slug: "genz", emoji: "💀" },
];

export function getEmojiBySlug(slug) {
  return emojis.find(e => e.slug === slug);
}
